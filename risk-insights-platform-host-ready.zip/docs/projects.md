# Project-by-project scope and honest status

| Proposed project | Included working MVP | Production additions required |
|---|---|---|
| Credit default prediction | Synthetic loan features, gradient boosting, ROC AUC, KS, PSI, pickle model | Time-based holdout, SHAP optional integration, MLflow model registry, fairness and governance |
| Transaction fraud/anomaly | Cost-weighted logistic model, Isolation Forest, ranked alert CSV | Labeled production data, calibrations, business-approved cost matrix |
| Drift dashboard | PSI metrics, JSON alert flag | Streamlit dashboard included; scheduled Airflow orchestration, Grafana, outcome-based decay monitoring still needed |
| Risk segmentation | KMeans, customer risk-profile aggregates | Segment stability and business sign-off |
| Feature engineering platform | Leakage-aware historical features, PySpark equivalent script | Feast registry/online store, feature monitoring |
| Spark on Kubernetes/OpenShift | Spark job and SparkApplication YAML | Cluster, operator CRDs, images, service accounts, autoscaling tests |
| Model serving | FastAPI scoring, typed input, health/readiness | Secure model retrieval, auth, rate limiting, metrics, canary rollout |
| End-to-end MLOps | CI tests, CLI orchestration, metrics files | Optional local MLflow metric logging included; retraining policies, approvals, Argo/Kubeflow still needed |
| Enterprise RAG | TF-IDF retrieval with verbatim citations | LLM generation, vector embeddings, permission-aware retrieval, eval suite |
| Natural-language to SQL | Allowlisted English-to-read-only SQL templates | LLM semantic parsing with AST validation, warehouse policy enforcement |
| Risk report summarizer | Source-derived deterministic narrative | Guarded LLM narrative and claim verification |
| Hybrid search | Lexical overlap + TF-IDF rank fusion | True BM25 and dense embeddings/reranker evaluation |
| Agentic analytics | Constrained tool router, audit JSONL | LLM tool selection, enterprise authorization, approval flows |
| Risk Insights capstone | Complete local pipeline linking model scores, queryable SQL, retrieval, summaries, and audit | Integrated production deployment, live data, security review |

This repository is a working educational prototype, **not** a regulated underwriting/fraud decision system. It has not been deployed in Kubernetes/OpenShift or used with real customer data.
